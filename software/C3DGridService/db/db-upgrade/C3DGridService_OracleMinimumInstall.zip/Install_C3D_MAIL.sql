/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* Author: Patrick Conrad (Ekagra Software Technologies)                 */
/* Date:   Dec. 13, 2007                                                 */
/* Description: This is the installation script for the C3D Mail Utility */
/*              This utility is used to send e-mail notifications. It    */
/*              allows for alerts to be send via e-mail when certain     */
/*              C3D utility activities occur.                            */
/*              C3D_UTILITY_MAILER - PL/SQL Package; Creates and sends   */
/*                  e-mails.  Uses Oracle UTL_SMPT package.              */
/*              C3D_MAIL_CTL - Table used to store controls for mail     */
/*                  messages                                             */
/*              C3D_MAIL_ARCHIVE - Holds all e-mails sent.               */
/*              Each of these objects are PUBLIC.                        */
/*                                                                       */
/* EXECUTION NOTE:  The following files should be placed into the same   */
/*                  directory. Before this file is execute, the install  */
/*                  directory should be the default directory.           */
/*          FILES:                                                       */
/*                 Install_C3D_Mail.sql - This file                      */
/*                 C3D_MAIL_CTL.sql - Mail control table                 */
/*                 C3D_MAIL_Message_CTL.sql - Message control table      */
/*                 C3D_MAIL_ARCHIVE.SQL - Mail archive table             */
/*                 C3D_UTILITY_MAILER.SQL - Mailing package              */
/*                 C3D_MAIL_CTL_DATA.sql - Data for table                */
/*                 C3D_MAIL_Message_CTL_DATA.sql - Data for table        */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/* Modification History:                                                 */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

-- Added condition to exit when error.  Just incase run accidently.
--WHENEVER SQLERROR EXIT

Select to_char(sysdate,'MM/DD/YYYY HH24:MI:SS') "Execution Date", User "User"
  from dual;

-- Spool a log file
spool install_c3d_mail.lst

--install the table, index and privs
Prompt ...Installing Table, Index, Synonym and Privileges.
@c3d_mail_archive.sql
@C3D_MAIL_CTL.sql
@C3D_MAIL_MESSAGE_CTL.sql
@C3D_MAIL_CTL_DATA.sql
@C3D_MAIL_MESSAGE_CTL_DATA.sql

-- Install Package
Prompt ...Installing Package, synonym and privileges
@C3D_UTILITY_MAILER.sql

grant select, insert, update, delete on C3D_MAIL_ARCHIVE     to PUBLIC;
grant select, insert, update, delete on C3D_MAIL_CTL         to PUBLIC;
grant select, insert, update, delete on C3D_MAIL_MESSAGE_CTL to PUBLIC;
grant execute                        on C3D_UTIL_MAILER      to PUBLIC;

create public synonym C3D_MAIL_ARCHIVE     for C3D_MAIL_ARCHIVE;
create public synonym C3D_MAIL_CTL         for C3D_MAIL_CTL;
create public synonym C3D_MAIL_MESSAGE_CTL for C3D_MAIL_MESSAGE_CTL;
create public synonym C3D_UTIL_MAILER      for C3D_UTILITY_MAILER;

spool off

PROMPT
PROMPT FINISHED!
PROMPT