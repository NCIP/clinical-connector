
CREATE OR REPLACE PACKAGE C3D_ENCRYPT AS

  FUNCTION encrypt(v_input IN VARCHAR2) RETURN VARCHAR2;
  FUNCTION decrypt(v_input IN VARCHAR2) RETURN VARCHAR2;

END;
/

CREATE OR REPLACE PACKAGE BODY C3D_ENCRYPT AS
   --
   -- Declare the values for the key.
   -- The package will be wrapped to hide the encryption key.
   --
   v_key          VARCHAR2(32)  := 'B#10j2#UJ%6?j1@A!1*%0j2#Jnd*?j1@';
   v_encrypt      VARCHAR2(2048);
   v_decrypt      VARCHAR2(2048);
   --
   -- FUNCTION ENCRYPT encrypts encrypted string
   --
   FUNCTION encrypt(v_input IN VARCHAR2) RETURN VARCHAR2 IS
   BEGIN
      v_encrypt := null;
      dbms_obfuscation_toolkit.DES3Encrypt( INPUT_STRING => v_input, KEY_STRING => v_key, ENCRYPTED_STRING => v_encrypt);
      --RETURN  rawtohex(UTL_RAW.CAST_TO_RAW(encrypted_string));
     RETURN  v_encrypt;
   END;
   --
   -- FUNCTION DECRYPT decrypts encrypted string
   --
   FUNCTION decrypt(v_input IN VARCHAR2) RETURN VARCHAR2 IS
   BEGIN
      v_decrypt    := null;
      v_encrypt    := null;
      dbms_obfuscation_toolkit.DES3Decrypt(INPUT_STRING => v_input, KEY_STRING => v_key, DECRYPTED_STRING => v_decrypt);
      RETURN  v_decrypt;
   END;
END;
/

