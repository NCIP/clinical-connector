/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* Author: Patrick Conrad (Ekagra Software Technologies)                 */
/* Date:   Dec. 13, 2007                                                 */
/* Description: This is the installation script for the C3D Lab Loader / */
/*              AutoLoader add-on                                        */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/* Modification History:                                                 */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

-- Added condition to exit when error.  Just incase run accidently.
--WHENEVER SQLERROR EXIT

Select to_char(sysdate,'MM/DD/YYYY HH24:MI:SS') "Execution Date", User "User"
  from dual;

-- Spool a log file
spool install_Autoloader.lst

--install the table, index and privs
Prompt ...Installing Table, Index, Synonym and Privileges.
@NCI_LABS_AUTOLOAD_HOLD.sql
@NCI_LABS_MANUAL_LOAD_BATCHES.sql
@NCI_LABS_MANUAL_LOAD_CTL.sql
@NCI_LABS_MANUAL_LOAD_HOLD.sql
@NCI_LABS_MANUAL_LOAD_STAGE.sql
@AutoLoader_Sequences.sql

-- Install Package
Prompt ...Installing Package, synonym and privileges
@nci_labs_manual_loader.plsql

spool off

PROMPT
PROMPT FINISHED!
PROMPT