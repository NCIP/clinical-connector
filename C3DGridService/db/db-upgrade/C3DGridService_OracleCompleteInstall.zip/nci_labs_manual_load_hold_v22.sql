
select 'Modify table NCI_LABS_MANUAL_HOLD, increase PATIENT_ID field to 20' NOTES
  from Dual;

alter table NCI_LABS_MANUAL_LOAD_HOLD
modify  (PATIENT_ID  varchar2(20));

select 'Modify table NCI_LABS_MANUAL_HOLD, increase OC_PATIENT_POS field to 20' NOTES
  from Dual;

alter table NCI_LABS_MANUAL_LOAD_HOLD
modify  (OC_PATIENT_POS varchar2(20));
