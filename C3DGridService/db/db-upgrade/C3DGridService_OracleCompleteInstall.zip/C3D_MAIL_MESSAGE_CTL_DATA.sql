--
-- C3D_MAIL_MESSAGE_CTL - Basic Table Data
--

INSERT INTO C3D_MAIL_MESSAGE_CTL ( UTIL_CODE, ALERT_TYPE, MESSAGE_TYPE, MESSAGE_TEXT )
VALUES (
'AUTO_LOADER', 'SUCCESS', 'CLOSING', 'This is the closing text for the AUTO_LOADER - SUCCESS Message');

INSERT INTO C3D_MAIL_MESSAGE_CTL ( UTIL_CODE, ALERT_TYPE, MESSAGE_TYPE, MESSAGE_TEXT )
VALUES (
'AUTO_LOADER', 'FAILURE', 'OPENING', 'The AutoLoader process of Lab Loader has experienced a FAILURE on OCDEV.');

INSERT INTO C3D_MAIL_MESSAGE_CTL ( UTIL_CODE, ALERT_TYPE, MESSAGE_TYPE, MESSAGE_TEXT )
VALUES (
'AUTO_LOADER', 'FAILURE', 'CLOSING', 'Please contact the C3D Utility Support Team for further information.');

INSERT INTO C3D_MAIL_MESSAGE_CTL ( UTIL_CODE, ALERT_TYPE, MESSAGE_TYPE, MESSAGE_TEXT )
VALUES (
'C3D_MAILER', 'FAILURE', 'OPENING', 'The C3D Mail Utility encountered an error while processing a request.');

INSERT INTO C3D_MAIL_MESSAGE_CTL ( UTIL_CODE, ALERT_TYPE, MESSAGE_TYPE, MESSAGE_TEXT )
VALUES (
'C3D_MAILER', 'WARNING', 'OPENING', 'The C3D Mail Utility encountered a WARNING while processing a request.');

INSERT INTO C3D_MAIL_MESSAGE_CTL ( UTIL_CODE, ALERT_TYPE, MESSAGE_TYPE, MESSAGE_TEXT )
VALUES (
'ALL', 'ALL', 'POSTSCRIPT', 'NOTE: This is an automated e-mail service.  Do not respond to this e-mail directly.  Contact #CONTACT# if you have any quetions.');

COMMIT;
