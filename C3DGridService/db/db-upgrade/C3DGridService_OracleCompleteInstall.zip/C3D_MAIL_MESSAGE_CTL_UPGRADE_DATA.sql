--
-- C3D_MAIL_MESSAGE_CTL - Basic Table Data
--

INSERT INTO C3D_MAIL_MESSAGE_CTL 
   ( UTIL_CODE, ALERT_TYPE, MESSAGE_TYPE, 
     MESSAGE_TEXT )
VALUES (
    'ALL', 'ALL', 'POSTSCRIPT', 
    'NOTE: This is an automated e-mail service.  Do not respond to this e-mail directly.  Contact #CONTACT# if you have any quetions.');

COMMIT;
