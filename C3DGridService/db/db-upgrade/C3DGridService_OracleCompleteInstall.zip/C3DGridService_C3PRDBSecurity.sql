-- This file contains the necessary Database privilevegs for the C3PR user
-- to allow the C3DGridService to execute.  

-- If Oracle Clinical exists in the database instance, then uncomment all of the
-- OC Related role/grant statements denoted by "-- OC Role".

-- Create C3PR user.  The owner of the C3DGridService database
-- related object for Oracle Clinical.

  CREATE USER C3PR
  IDENTIFIED BY VALUES '200B8E0E2DF24495'
  DEFAULT TABLESPACE &&USERS_TABLESPACE_NAME
  TEMPORARY TABLESPACE &&TEMPORARY_TABLESPACE_NAME
  PROFILE DEFAULT
  ACCOUNT UNLOCK;


-- Roles, Priviledges and Grants

  GRANT CONNECT TO C3PR;
 
  GRANT RESOURCE TO C3PR;

  GRANT RXC_ANY TO C3PR; -- OC Role 

  GRANT RXC_RDC TO C3PR; -- OC Role 

  GRANT RXC_SUPER TO C3PR; -- OC Role 

  GRANT OCL_ACCESS TO C3PR; -- OC Role 

  GRANT RDC_ACCESS TO C3PR; -- OC Role 

  GRANT RXCLIN_MOD TO C3PR; -- OC Role 

  GRANT RXCLIN_READ TO C3PR; -- OC Role 

  GRANT OCLAPI_UPDATE TO C3PR; -- OC Role 

  GRANT OC_STUDY_ROLE TO C3PR; -- OC Role 

  GRANT OCLAPI_UPDATET TO C3PR; -- OC Role 

  GRANT OCLAPI_KEY_CHANGES TO C3PR; -- OC Role 

  GRANT OCLAPI_KEY_CHANGEST TO C3PR; -- OC Role 
	

  ALTER USER C3PR DEFAULT ROLE ALL;


-- 3 System Privileges for C3PR 
  GRANT DROP PUBLIC SYNONYM TO C3PR;

  GRANT UNLIMITED TABLESPACE TO C3PR;

  GRANT CREATE PUBLIC SYNONYM TO C3PR;


-- 10 Oracle Clinical Object Privileges for C3PR 
-- These must be granted explicitly.
  GRANT SELECT ON  RXC.DCI_BOOKS TO C3PR; -- OC Role 

  GRANT SELECT ON  RXC.OS_FILE_SEQ TO C3PR; -- OC Role 

  GRANT SELECT ON  RXC.PSUB_COMFILE_SEQ TO C3PR; -- OC Role 

  GRANT SELECT ON  RXC.REFERENCE_CODELIST_VALUES TO C3PR; -- OC Role 

  GRANT SELECT ON  RXA_DES.CLINICAL_STUDIES TO C3PR; -- OC Role 

  GRANT SELECT, UPDATE ON  RXA_DES.PATIENT_POSITIONS TO C3PR; -- OC Role 

  GRANT DELETE, INSERT, SELECT, UPDATE ON  RXC.BATCH_JOBS TO C3PR; -- OC Role 

  GRANT DELETE, INSERT, SELECT, UPDATE ON  RXC.OS_FILES TO C3PR; -- OC Role 


