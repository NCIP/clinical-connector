

CREATE TABLE STUDY_PRIVATE_CDE
(
  STUDY        VARCHAR2(15 BYTE)                NOT NULL,
  CDE_ID       VARCHAR2(40 BYTE)                NOT NULL,
  CDE_VERSION  VARCHAR2(30 BYTE)                NOT NULL
)
/




