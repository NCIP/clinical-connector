/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* Author: Patrick Conrad (Ekagra Software Technologies)                 */
/* Date:   Feb 1, 2010                                                   */
/* Description: This is the installation script for the C3D CSM Security */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/* Modification History:                                                 */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

-- Added condition to exit when error.  Just incase run accidently.
--WHENEVER SQLERROR EXIT

Select to_char(sysdate,'MM/DD/YYYY HH24:MI:SS') "Execution Date", User "User"
  from dual;

-- Spool a log file
spool install_C3D_CSM.lst

--install the table, index and privs
Prompt ...Installing Table, Index, Synonym and Privileges.
@c3d_csm_sequences.sql
@c3d_csm_tables.sql
@c3d_csm_table_data.sql

-- Install Package
Prompt ...Installing Package, synonym and privileges
@c3d_csm_c3d_encrypt_pkg.sql

spool off

PROMPT
PROMPT FINISHED!
PROMPT