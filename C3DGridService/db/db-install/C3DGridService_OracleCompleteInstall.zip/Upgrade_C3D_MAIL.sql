/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* Author: Patrick Conrad (Ekagra Software Technologies)                 */
/* Date:   Dec. 13, 2007                                                 */
/* Description: This is the UPGRADE script for the C3D Mail Utility      */
/*              It will execute UPGRADE scripts only.  It will be used   */
/*              to apply changes to existing installations of the        */
/*              C3D Utility Mailer.                                      */
/*                                                                       */
/* EXECUTION NOTE:  The following files should be placed into the same   */
/*                  directory. Before this file is executed, the install */
/*                  directory should be the default directory.           */
/* FILES:                                                                */
/*    UPGRADE_C3D_Mail.SQL - This file                                   */
/*    C3D_UTILITY_MAILER.SQL - Mailing package                           */
/*    C3D_MAIL_CTL_UPGRADE_DATA.SQL - Upgrade Data for control table     */
/*    C3D_MAIL_MESSAGE_CTL_UPGRADE_DATA.SQL - Upgrade Data for table     */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/* Modification History:                                                 */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

-- Added condition to exit when error.  Just incase run accidently.
--WHENEVER SQLERROR EXIT

Select to_char(sysdate,'MM/DD/YYYY HH24:MI:SS') "Execution Date", User "User"
  from dual;

-- Spool a log file
spool upgrade_c3d_mail.lst

--install the table, index and privs
--Prompt ...Installing Table, Index, Synonym and Privileges.

--install the table, index and privs
Prompt ...Inserting NEW control records.
@C3D_MAIL_CTL_UPGRADE_DATA.sql
@C3D_MAIL_MESSAGE_CTL_UPGRADE_DATA.sql

-- Install Package
Prompt ...Installing Package
@C3D_UTILITY_MAILER.sql

-- Display Notes
@UPGRADE_NOTES.SQL
spool off

PROMPT
PROMPT FINISHED!
PROMPT